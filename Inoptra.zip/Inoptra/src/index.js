import React from "react";
import ReactDOM from "react-dom";
import BlackJack from "./components/stick";
import "./styles.css";

function App() {
  return <BlackJack />;
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
