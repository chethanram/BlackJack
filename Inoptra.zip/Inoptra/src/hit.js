import { useState } from "react";

const colors = ["hearts", "spades", "clubs", "diamonds"];
const ranks = [
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "10",
  "J",
  "Q",
  "K",
  "A"
];

const Card = (color, rank) => {
  return {
    color: color,
    rank: rank
  };
};
const cardsAvailable = colors
  .map(c => {
    return ranks.map(r => Card(c, r));
  })
  .flat();

const useDeck = () => {
  const [cards, setCards] = useState(null);
  const init = () => {
    setCards(shuffle([...cardsAvailable]));
  };
  const shuffle = deck => {
    var currentIndex = deck.length,
      temporaryValue,
      randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {
      // Pick a remaining element...
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;

      // And swap it with the current element.
      temporaryValue = deck[currentIndex];
      deck[currentIndex] = deck[randomIndex];
      deck[randomIndex] = temporaryValue;
    }

    return deck;
  };

  const draw = () => {
    let card = cards[cards.length - 1];
    setCards(cards.slice(0, -1));
    return card;
  };

  return [cards, draw, init];
};

export default useDeck;
