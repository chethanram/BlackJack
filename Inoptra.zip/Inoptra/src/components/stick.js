import React, { useState, useEffect } from "react";
import useDeck from "../hit";

const BlackJack = props => {
  const [cards, draw, init] = useDeck();
  const [playerDrawnCards, setPlayerDrawnCards] = useState([]);

  const [playersTurn, setPlayersTurn] = useState(true);

  useEffect(init, [0]);
  const drawForPlayer = () => {
    setPlayerDrawnCards(playerDrawnCards.concat(draw()));
  };

  return (
    <div className={"game"} onClick={drawForPlayer}>
      {playerDrawnCards.map(c => (
        <p>{c.rank + " - " + c.color}</p>
      ))}
    </div>
  );
};

export default BlackJack;
